package textExcel;

/** 
 * @author Jeffrey Ding
 * @version 02/23/2023
 */ 

public class ValueCell extends RealCell implements Cell {

	public ValueCell(String value) {
		super(value);
	}
}
